# CMake generated Testfile for 
# Source directory: /home/guilherme/Desktop/RAPL_Measurements/raplcap
# Build directory: /home/guilherme/Desktop/RAPL_Measurements/raplcap/_build
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
subdirs("rapl-configure")
subdirs("test")
subdirs("msr")
subdirs("powercap")
