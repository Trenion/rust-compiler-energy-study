# CMake generated Testfile for 
# Source directory: /home/guilherme/Desktop/RAPL_Measurements/raplcap/test
# Build directory: /home/guilherme/Desktop/RAPL_Measurements/raplcap/_build/test
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
