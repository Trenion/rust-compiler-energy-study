
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "/home/guilherme/Desktop/RAPL_Measurements/raplcap/msr/raplcap-cpuid.c" "msr/CMakeFiles/raplcap-msr-common-unit-test.dir/raplcap-cpuid.c.o" "gcc" "msr/CMakeFiles/raplcap-msr-common-unit-test.dir/raplcap-cpuid.c.o.d"
  "/home/guilherme/Desktop/RAPL_Measurements/raplcap/msr/raplcap-msr-common.c" "msr/CMakeFiles/raplcap-msr-common-unit-test.dir/raplcap-msr-common.c.o" "gcc" "msr/CMakeFiles/raplcap-msr-common-unit-test.dir/raplcap-msr-common.c.o.d"
  "/home/guilherme/Desktop/RAPL_Measurements/raplcap/msr/test/raplcap-msr-common-test.c" "msr/CMakeFiles/raplcap-msr-common-unit-test.dir/test/raplcap-msr-common-test.c.o" "gcc" "msr/CMakeFiles/raplcap-msr-common-unit-test.dir/test/raplcap-msr-common-test.c.o.d"
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_LINKED_INFO_FILES
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_FORWARD_LINKED_INFO_FILES
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
