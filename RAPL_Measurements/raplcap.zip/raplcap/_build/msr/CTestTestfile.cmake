# CMake generated Testfile for 
# Source directory: /home/guilherme/Desktop/RAPL_Measurements/raplcap/msr
# Build directory: /home/guilherme/Desktop/RAPL_Measurements/raplcap/_build/msr
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
add_test([=[raplcap-msr-unit-test]=] "raplcap-msr-unit-test")
set_tests_properties([=[raplcap-msr-unit-test]=] PROPERTIES  _BACKTRACE_TRIPLES "/home/guilherme/Desktop/RAPL_Measurements/raplcap/test/CMakeLists.txt;6;add_test;/home/guilherme/Desktop/RAPL_Measurements/raplcap/msr/CMakeLists.txt;20;add_raplcap_tests;/home/guilherme/Desktop/RAPL_Measurements/raplcap/msr/CMakeLists.txt;0;")
add_test([=[raplcap-msr-common-unit-test]=] "raplcap-msr-common-unit-test")
set_tests_properties([=[raplcap-msr-common-unit-test]=] PROPERTIES  _BACKTRACE_TRIPLES "/home/guilherme/Desktop/RAPL_Measurements/raplcap/msr/CMakeLists.txt;26;add_test;/home/guilherme/Desktop/RAPL_Measurements/raplcap/msr/CMakeLists.txt;0;")
