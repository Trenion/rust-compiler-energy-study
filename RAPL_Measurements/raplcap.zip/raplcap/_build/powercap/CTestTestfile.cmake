# CMake generated Testfile for 
# Source directory: /home/guilherme/Desktop/RAPL_Measurements/raplcap/powercap
# Build directory: /home/guilherme/Desktop/RAPL_Measurements/raplcap/_build/powercap
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
add_test([=[raplcap-powercap-unit-test]=] "raplcap-powercap-unit-test")
set_tests_properties([=[raplcap-powercap-unit-test]=] PROPERTIES  _BACKTRACE_TRIPLES "/home/guilherme/Desktop/RAPL_Measurements/raplcap/test/CMakeLists.txt;6;add_test;/home/guilherme/Desktop/RAPL_Measurements/raplcap/powercap/CMakeLists.txt;23;add_raplcap_tests;/home/guilherme/Desktop/RAPL_Measurements/raplcap/powercap/CMakeLists.txt;0;")
