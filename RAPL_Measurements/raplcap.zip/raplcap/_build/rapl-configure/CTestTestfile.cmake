# CMake generated Testfile for 
# Source directory: /home/guilherme/Desktop/RAPL_Measurements/raplcap/rapl-configure
# Build directory: /home/guilherme/Desktop/RAPL_Measurements/raplcap/_build/rapl-configure
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
