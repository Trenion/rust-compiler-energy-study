# CMake generated Testfile for 
# Source directory: /home/guilherme/Desktop/RAPL_Measurements/powercap/test
# Build directory: /home/guilherme/Desktop/RAPL_Measurements/powercap/_build/test
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
add_test([=[powercap-common-test]=] "powercap-common-test")
set_tests_properties([=[powercap-common-test]=] PROPERTIES  _BACKTRACE_TRIPLES "/home/guilherme/Desktop/RAPL_Measurements/powercap/test/CMakeLists.txt;4;add_test;/home/guilherme/Desktop/RAPL_Measurements/powercap/test/CMakeLists.txt;9;add_unit_test;/home/guilherme/Desktop/RAPL_Measurements/powercap/test/CMakeLists.txt;0;")
add_test([=[powercap-test]=] "powercap-test")
set_tests_properties([=[powercap-test]=] PROPERTIES  _BACKTRACE_TRIPLES "/home/guilherme/Desktop/RAPL_Measurements/powercap/test/CMakeLists.txt;4;add_test;/home/guilherme/Desktop/RAPL_Measurements/powercap/test/CMakeLists.txt;13;add_unit_test;/home/guilherme/Desktop/RAPL_Measurements/powercap/test/CMakeLists.txt;0;")
add_test([=[powercap-sysfs-test]=] "powercap-sysfs-test")
set_tests_properties([=[powercap-sysfs-test]=] PROPERTIES  _BACKTRACE_TRIPLES "/home/guilherme/Desktop/RAPL_Measurements/powercap/test/CMakeLists.txt;4;add_test;/home/guilherme/Desktop/RAPL_Measurements/powercap/test/CMakeLists.txt;22;add_unit_test;/home/guilherme/Desktop/RAPL_Measurements/powercap/test/CMakeLists.txt;0;")
