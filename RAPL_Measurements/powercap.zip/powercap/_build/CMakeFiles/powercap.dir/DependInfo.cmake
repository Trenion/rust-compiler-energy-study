
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "/home/guilherme/Desktop/RAPL_Measurements/powercap/src/powercap-common.c" "CMakeFiles/powercap.dir/src/powercap-common.c.o" "gcc" "CMakeFiles/powercap.dir/src/powercap-common.c.o.d"
  "/home/guilherme/Desktop/RAPL_Measurements/powercap/src/powercap-rapl-sysfs.c" "CMakeFiles/powercap.dir/src/powercap-rapl-sysfs.c.o" "gcc" "CMakeFiles/powercap.dir/src/powercap-rapl-sysfs.c.o.d"
  "/home/guilherme/Desktop/RAPL_Measurements/powercap/src/powercap-rapl.c" "CMakeFiles/powercap.dir/src/powercap-rapl.c.o" "gcc" "CMakeFiles/powercap.dir/src/powercap-rapl.c.o.d"
  "/home/guilherme/Desktop/RAPL_Measurements/powercap/src/powercap-sysfs.c" "CMakeFiles/powercap.dir/src/powercap-sysfs.c.o" "gcc" "CMakeFiles/powercap.dir/src/powercap-sysfs.c.o.d"
  "/home/guilherme/Desktop/RAPL_Measurements/powercap/src/powercap.c" "CMakeFiles/powercap.dir/src/powercap.c.o" "gcc" "CMakeFiles/powercap.dir/src/powercap.c.o.d"
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_LINKED_INFO_FILES
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_FORWARD_LINKED_INFO_FILES
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
