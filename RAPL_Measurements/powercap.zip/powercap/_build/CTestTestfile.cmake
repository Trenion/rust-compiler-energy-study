# CMake generated Testfile for 
# Source directory: /home/guilherme/Desktop/RAPL_Measurements/powercap
# Build directory: /home/guilherme/Desktop/RAPL_Measurements/powercap/_build
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
subdirs("test")
subdirs("utils")
