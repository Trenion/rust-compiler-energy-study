
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "/home/guilherme/Desktop/RAPL_Measurements/powercap/utils/rapl-info.c" "utils/CMakeFiles/rapl-info.dir/rapl-info.c.o" "gcc" "utils/CMakeFiles/rapl-info.dir/rapl-info.c.o.d"
  "/home/guilherme/Desktop/RAPL_Measurements/powercap/utils/util-common.c" "utils/CMakeFiles/rapl-info.dir/util-common.c.o" "gcc" "utils/CMakeFiles/rapl-info.dir/util-common.c.o.d"
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_LINKED_INFO_FILES
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_FORWARD_LINKED_INFO_FILES
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
