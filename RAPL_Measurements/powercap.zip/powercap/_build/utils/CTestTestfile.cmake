# CMake generated Testfile for 
# Source directory: /home/guilherme/Desktop/RAPL_Measurements/powercap/utils
# Build directory: /home/guilherme/Desktop/RAPL_Measurements/powercap/_build/utils
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
